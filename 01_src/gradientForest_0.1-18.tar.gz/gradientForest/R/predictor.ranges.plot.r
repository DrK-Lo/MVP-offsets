predictor.ranges.plot <- function (obj, ...)
UseMethod("predictor.ranges.plot")
