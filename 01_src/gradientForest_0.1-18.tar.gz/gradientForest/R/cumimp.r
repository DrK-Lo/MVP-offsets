cumimp <- function (x, ...)
UseMethod("cumimp")
